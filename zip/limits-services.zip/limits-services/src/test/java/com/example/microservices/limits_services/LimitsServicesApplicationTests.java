package com.example.microservices.limits_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitsServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
