package com.example.restful_web_services.restful_web_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
