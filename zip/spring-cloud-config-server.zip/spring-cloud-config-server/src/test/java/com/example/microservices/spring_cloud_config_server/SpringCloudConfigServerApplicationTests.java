package com.example.microservices.spring_cloud_config_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
